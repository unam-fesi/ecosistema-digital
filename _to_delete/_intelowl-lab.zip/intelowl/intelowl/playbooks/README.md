# Playbooks de IntelOwl · sync vs async

Un **Playbook** de IntelOwl es un conjunto guardado de analizadores (y
conectores/pivotes) que corren juntos sobre un tipo de observable. Aquí armamos
dos, según *cómo se consumen los datos*:

## Demo_Sync_Online — consumo en línea (síncrono)
Analizadores **rápidos** que responden en segundos y sirven para mostrar algo al
instante en la demo:

- **Geolocalización / posición GPS** (lat, lon, ciudad, país)
- **Reputación** de IP/dominio (listas de bloqueo, nodos Tor, malware trackers)
- **DNS / WHOIS** básico

El front (`webapp`) los ejecuta y **espera** el resultado (poll corto) para
pintarlo con mapa incluido.

## Demo_Async_Enrichment — enriquecimiento posterior (asíncrono)
Analizadores **más lentos o pesados** (DNS pasivo, correlaciones, fuentes que
tardan). No tiene sentido bloquear la pantalla esperándolos: se **lanzan y se
consultan después** por su `job_id`. Esto es el patrón real de un pipeline de
threat intel: lo urgente se ve en línea; el enriquecimiento se acumula.

## ¿Por qué "sin suscripción"?
El script `create_playbooks.py` pregunta a **tu** instancia qué analizadores
están `configured` (es decir, no les falta ningún secreto/API key) y solo usa
esos. Así nunca metemos analizadores de pago o que fallarían por falta de token.

## Cómo generarlos
```bash
export INTELOWL_URL=http://localhost
export INTELOWL_TOKEN=xxxxx          # token de la GUI de IntelOwl
python3 create_playbooks.py
```
Intenta crearlos por API y, pase lo que pase, deja las listas en
`playbook_sets.json` por si prefieres crearlos desde la GUI
(botón **Create playbook**, o **Save as Playbook** después de un análisis).

> Nota: la geolocalización nativa de IntelOwl (**Maxmind / GeoLite2**) pide una
> licencia **gratuita** de MaxMind (registro sin costo). Si no la configuras, el
> front igual muestra la posición usando un servicio keyless (ip-api) como
> respaldo, claramente etiquetado como tal.
