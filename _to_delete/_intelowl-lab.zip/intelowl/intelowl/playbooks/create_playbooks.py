#!/usr/bin/env python3
# ============================================================================
#  create_playbooks.py
#
#  Descubre los analizadores GRATUITOS (configurados, sin secreto) de tu
#  instancia de IntelOwl y arma dos "playbooks" de demo:
#
#     Demo_Sync_Online       → rápidos: geolocalización + reputación + DNS
#     Demo_Async_Enrichment  → lentos:  el resto (enriquecimiento posterior)
#
#  Intenta crearlos vía API. Si tu versión de IntelOwl no acepta la creación
#  por API, imprime las listas para que los guardes desde la GUI
#  ("Save as Playbook" tras un análisis, o botón "Create playbook").
#
#  Uso:
#     export INTELOWL_URL=http://localhost
#     export INTELOWL_TOKEN=xxxxx
#     python3 create_playbooks.py
# ============================================================================
import json
import os
import sys

import requests

URL = os.environ.get("INTELOWL_URL", "http://localhost").rstrip("/")
TOKEN = os.environ.get("INTELOWL_TOKEN", "")
VERIFY = os.environ.get("VERIFY_TLS", "false").lower() == "true"

SYNC_HINTS = ["maxmind", "geo", "geoip", "greynoise", "talos", "tor", "abuseipdb",
              "threatfox", "feodo", "spamhaus", "firehol", "dns", "quad9",
              "google", "classic_dns", "whois", "robtex"]

if not TOKEN:
    sys.exit("Falta INTELOWL_TOKEN (créalo en la GUI → API Access/Sessions).")

S = requests.Session()
S.headers.update({"Authorization": f"Token {TOKEN}"})


def configured_analyzers():
    r = S.get(f"{URL}/api/analyzer", timeout=30, verify=VERIFY)
    r.raise_for_status()
    data = r.json()
    items = data.get("results", data) if isinstance(data, dict) else data
    out = []
    for a in items:
        name = a.get("name") or a.get("analyzer_name")
        if not name or a.get("disabled"):
            continue
        ver = a.get("verification") or {}
        if not ver.get("configured", True):
            continue
        out.append({
            "name": name,
            "supported": a.get("observable_supported") or a.get("supported_types") or [],
        })
    return out


def split(analyzers, classifications):
    sync, asyn = [], []
    for a in analyzers:
        sup = a["supported"]
        if sup and not (set(sup) & set(classifications)):
            continue
        low = a["name"].lower()
        (sync if any(h in low for h in SYNC_HINTS) else asyn).append(a["name"])
    return sorted(set(sync)), sorted(set(asyn))


def try_create(name, description, analyzers, classifications):
    """Intento best-effort de crear el playbook por API."""
    payload = {
        "name": name,
        "description": description,
        "type": classifications,
        "analyzers": analyzers,
        "connectors": [],
        "pivots": [],
        "runtime_configuration": {},
        "scan_mode": 2,
        "scan_check_time": "24:00:00",
        "tlp": "CLEAR",
    }
    try:
        r = S.post(f"{URL}/api/playbook", json=payload, timeout=30, verify=VERIFY)
        if r.status_code in (200, 201):
            print(f"  ✓ Playbook '{name}' creado por API.")
            return True
        print(f"  ⚠ API respondió {r.status_code} al crear '{name}': {r.text[:180]}")
    except requests.RequestException as e:
        print(f"  ⚠ No se pudo crear '{name}' por API: {e}")
    return False


def main():
    classifications = ["ip", "domain", "generic"]
    analyzers = configured_analyzers()
    print(f"Analizadores configurados (sin secreto): {len(analyzers)}\n")

    sync, asyn = split(analyzers, classifications)

    print("── Demo_Sync_Online (rápidos, para consumo en línea) ──")
    print("  " + (", ".join(sync) or "(ninguno)"))
    print("\n── Demo_Async_Enrichment (enriquecimiento posterior) ──")
    print("  " + (", ".join(asyn) or "(ninguno)"))
    print()

    try_create("Demo_Sync_Online",
               "Geolocalización + reputación + DNS para respuesta inmediata.",
               sync, classifications)
    try_create("Demo_Async_Enrichment",
               "Analizadores de enriquecimiento para procesamiento asíncrono.",
               asyn, classifications)

    # deja las listas en un JSON por si quieres crearlos a mano en la GUI
    with open("playbook_sets.json", "w") as f:
        json.dump({"sync": sync, "async": asyn}, f, indent=2)
    print("\nGuardé las listas en playbook_sets.json")
    print("Si la API no creó los playbooks, créalos desde la GUI con estas listas "
          "(botón 'Create playbook' o 'Save as Playbook' tras un análisis).")


if __name__ == "__main__":
    main()
