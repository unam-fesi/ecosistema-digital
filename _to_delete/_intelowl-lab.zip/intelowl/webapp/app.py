#!/usr/bin/env python3
# ============================================================================
#  Vulture · Front demo de IntelOwl  (puerto 8666)
#
#  Recibe un NOMBRE o una IP y:
#    · SÍNCRONO   → corre analizadores rápidos (geo/GPS + reputación) y espera
#                   el resultado para mostrarlo en línea, con mapa.
#    · ASÍNCRONO  → lanza analizadores de enriquecimiento (más lentos) y
#                   devuelve el job_id para consultarlo después en IntelOwl.
#
#  Solo usa analizadores que IntelOwl reporta como "configurados" (es decir,
#  los que NO requieren secreto/suscripción). El reparto sync/async se hace
#  por nombre de analizador (heurística editable abajo).
#
#  Config por variables de entorno (ver .env.example):
#    INTELOWL_URL     p.ej. http://localhost           (IntelOwl en la Legion7)
#    INTELOWL_TOKEN   API token creado en la GUI de IntelOwl
#    PORT             8666
#    VERIFY_TLS       "true"/"false"  (si IntelOwl usa https con cert propio)
# ============================================================================
import ipaddress
import os
import re

import requests
from flask import Flask, jsonify, render_template_string, request

INTELOWL_URL = os.environ.get("INTELOWL_URL", "http://localhost").rstrip("/")
INTELOWL_TOKEN = os.environ.get("INTELOWL_TOKEN", "")
PORT = int(os.environ.get("PORT", "8666"))
VERIFY_TLS = os.environ.get("VERIFY_TLS", "false").lower() == "true"
SYNC_TIMEOUT = int(os.environ.get("SYNC_TIMEOUT", "35"))  # segundos que esperamos en modo síncrono

# Analizadores "rápidos" (modo síncrono): geolocalización, DNS, reputación
# de consulta directa. Cualquier otro analizador configurado se usa para el
# enriquecimiento ASÍNCRONO. Coincidencia por subcadena, sin distinguir mayúsculas.
SYNC_HINTS = [
    "maxmind", "geo", "geoip", "greynoise", "talos", "tor",
    "abuseipdb", "threatfox", "feodo", "spamhaus", "firehol",
    "dns", "quad9", "google", "classic_dns", "whois", "robtex",
]

app = Flask(__name__)
S = requests.Session()
S.headers.update({"Authorization": f"Token {INTELOWL_TOKEN}", "User-Agent": "vulture-intelowl-demo"})


# ─────────────────────────── helpers IntelOwl ───────────────────────────
def classify(target: str) -> str:
    """Deduce el tipo de observable que espera IntelOwl."""
    t = target.strip()
    try:
        ipaddress.ip_address(t)
        return "ip"
    except ValueError:
        pass
    if re.match(r"^[a-z][a-z0-9+.\-]*://", t, re.I):
        return "url"
    if re.fullmatch(r"[0-9a-f]{32}|[0-9a-f]{40}|[0-9a-f]{64}", t, re.I):
        return "hash"
    if re.fullmatch(r"(?=.{1,253}$)([a-z0-9]([a-z0-9\-]{0,61}[a-z0-9])?\.)+[a-z]{2,}", t, re.I):
        return "domain"
    return "generic"  # un nombre de persona/organización, etc.


def get_configured_analyzers(classification: str):
    """Devuelve (sync, async) con los analizadores configurados que soportan el tipo."""
    url = f"{INTELOWL_URL}/api/analyzer"
    r = S.get(url, timeout=30, verify=VERIFY_TLS)
    r.raise_for_status()
    data = r.json()
    items = data.get("results", data) if isinstance(data, dict) else data

    sync, asyn = [], []
    for a in items:
        name = a.get("name") or a.get("analyzer_name")
        if not name or a.get("disabled"):
            continue
        # ¿está configurado (sin secretos faltantes)?
        ver = a.get("verification") or {}
        configured = ver.get("configured", True)
        if not configured:
            continue
        # ¿soporta este tipo de observable?
        supported = a.get("observable_supported") or a.get("supported_types") or []
        if supported and classification not in supported:
            continue
        low = name.lower()
        if any(h in low for h in SYNC_HINTS):
            sync.append(name)
        else:
            asyn.append(name)
    return sorted(set(sync)), sorted(set(asyn))


def submit(target, classification, analyzers):
    """Lanza el análisis y devuelve el job_id."""
    payload = {
        "observable_name": target,
        "observable_classification": classification,
        "analyzers_requested": analyzers,
        "tlp": "CLEAR",
        "scan_mode": 2,          # 2 = forzar nuevo análisis
    }
    r = S.post(f"{INTELOWL_URL}/api/analyze_observable", json=payload, timeout=60, verify=VERIFY_TLS)
    r.raise_for_status()
    d = r.json()
    # el id puede venir como job_id, id o dentro de results[0]
    return d.get("job_id") or d.get("id") or (d.get("results", [{}])[0].get("job_id"))


def get_job(job_id):
    r = S.get(f"{INTELOWL_URL}/api/jobs/{job_id}", timeout=30, verify=VERIFY_TLS)
    r.raise_for_status()
    return r.json()


def find_geo(job):
    """Busca lat/lon dentro de los reportes de los analizadores."""
    def walk(o):
        if isinstance(o, dict):
            keys = {k.lower(): k for k in o}
            lat = keys.get("latitude") or keys.get("lat")
            lon = keys.get("longitude") or keys.get("lon") or keys.get("lng")
            if lat and lon:
                try:
                    return float(o[lat]), float(o[lon])
                except (TypeError, ValueError):
                    pass
            if "loc" in keys and isinstance(o[keys["loc"]], str) and "," in o[keys["loc"]]:
                try:
                    a, b = o[keys["loc"]].split(",")[:2]
                    return float(a), float(b)
                except ValueError:
                    pass
            for v in o.values():
                g = walk(v)
                if g:
                    return g
        elif isinstance(o, list):
            for v in o:
                g = walk(v)
                if g:
                    return g
        return None
    for rep in job.get("analyzer_reports", []):
        g = walk(rep.get("report"))
        if g:
            return g
    return None


def geo_fallback(target, classification):
    """GPS garantizado sin API key (solo para IPs) usando ip-api.com."""
    if classification != "ip":
        return None
    try:
        r = requests.get(f"http://ip-api.com/json/{target}", timeout=8)
        j = r.json()
        if j.get("status") == "success":
            return (j["lat"], j["lon"], f"{j.get('city','')}, {j.get('country','')}".strip(", "))
    except requests.RequestException:
        return None
    return None


# ─────────────────────────────── rutas ───────────────────────────────
@app.get("/health")
def health():
    try:
        S.get(f"{INTELOWL_URL}/api/analyzer", timeout=10, verify=VERIFY_TLS).raise_for_status()
        return jsonify(ok=True, intelowl=INTELOWL_URL)
    except requests.RequestException as e:
        return jsonify(ok=False, error=str(e)), 502


@app.post("/analyze")
def analyze():
    body = request.get_json(silent=True) or request.form
    target = (body.get("target") or "").strip()
    mode = (body.get("mode") or "sync").lower()
    if not target:
        return jsonify(error="Escribe un nombre o una IP."), 400

    classification = classify(target)
    try:
        sync_an, async_an = get_configured_analyzers(classification)
    except requests.RequestException as e:
        return jsonify(error=f"No pude hablar con IntelOwl: {e}"), 502

    if mode == "async":
        chosen = async_an or sync_an
        if not chosen:
            return jsonify(error="No hay analizadores configurados para este tipo."), 400
        try:
            job_id = submit(target, classification, chosen)
        except requests.RequestException as e:
            return jsonify(error=f"Fallo al enviar a IntelOwl: {e}"), 502
        return jsonify(
            mode="async", job_id=job_id, classification=classification,
            analyzers=chosen,
            job_url=f"{INTELOWL_URL}/jobs/{job_id}/visualizer",
            message="Enviado a enriquecimiento asíncrono. Consulta el job cuando quieras.",
        )

    # ── modo síncrono ──
    chosen = sync_an or async_an[:5]
    if not chosen:
        return jsonify(error="No hay analizadores configurados para este tipo."), 400
    try:
        job_id = submit(target, classification, chosen)
    except requests.RequestException as e:
        return jsonify(error=f"Fallo al enviar a IntelOwl: {e}"), 502

    import time
    deadline = time.time() + SYNC_TIMEOUT
    job = {}
    terminal = {"reported_without_fails", "reported_with_fails", "failed", "killed"}
    while time.time() < deadline:
        try:
            job = get_job(job_id)
        except requests.RequestException:
            time.sleep(2); continue
        if job.get("status") in terminal:
            break
        time.sleep(2)

    geo = find_geo(job)
    geo_src = "IntelOwl"
    if not geo:
        fb = geo_fallback(target, classification)
        if fb:
            geo = (fb[0], fb[1]); geo_src = "ip-api (sin key)"

    reports = [{
        "name": rp.get("name") or rp.get("analyzer_name"),
        "status": rp.get("status"),
        "report": rp.get("report"),
        "errors": rp.get("errors"),
    } for rp in job.get("analyzer_reports", [])]

    return jsonify(
        mode="sync", job_id=job_id, classification=classification,
        status=job.get("status"), analyzers=chosen, reports=reports,
        geo={"lat": geo[0], "lon": geo[1], "source": geo_src} if geo else None,
        job_url=f"{INTELOWL_URL}/jobs/{job_id}/visualizer",
        also_async=async_an,
    )


@app.get("/job/<int:job_id>")
def job_status(job_id):
    try:
        job = get_job(job_id)
    except requests.RequestException as e:
        return jsonify(error=str(e)), 502
    return jsonify(
        status=job.get("status"),
        reports=[{"name": r.get("name") or r.get("analyzer_name"), "status": r.get("status")}
                 for r in job.get("analyzer_reports", [])],
        job_url=f"{INTELOWL_URL}/jobs/{job_id}/visualizer",
    )


@app.get("/")
def index():
    return render_template_string(PAGE, intelowl=INTELOWL_URL, port=PORT)


PAGE = r"""<!DOCTYPE html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Vulture · IntelOwl demo</title>
<style>
:root{--bg:#0a0e14;--card:#121826;--line:#1e293b;--txt:#e6edf3;--mut:#8b98a9;--acc:#38bdf8;--ok:#34d399;--warn:#f5b841;--err:#ef6461}
*{box-sizing:border-box}body{margin:0;font-family:ui-sans-serif,system-ui,Segoe UI,Roboto,sans-serif;background:radial-gradient(1200px 600px at 70% -10%,#12233b,#0a0e14);color:var(--txt)}
.wrap{max-width:1000px;margin:0 auto;padding:28px 20px 60px}
h1{font-size:1.5rem;margin:0 0 2px}.sub{color:var(--mut);font-size:.9rem;margin-bottom:22px}
.logo{font-size:1.7rem}
.card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:18px;margin-bottom:16px}
input[type=text]{width:100%;padding:13px 14px;border-radius:10px;border:1px solid var(--line);background:#0d1420;color:var(--txt);font-size:1rem}
.row{display:flex;gap:10px;flex-wrap:wrap;margin-top:12px}
button{border:0;border-radius:10px;padding:12px 18px;font-weight:700;font-size:.92rem;cursor:pointer}
.b-sync{background:var(--acc);color:#04202e}.b-async{background:#334155;color:#e6edf3}
button:disabled{opacity:.5;cursor:wait}
.pill{display:inline-block;padding:3px 9px;border-radius:999px;font-size:.72rem;font-weight:700}
.pill.ip{background:#0ea5e922;color:#7dd3fc}.pill.generic{background:#a78bfa22;color:#c4b5fd}.pill.domain{background:#34d39922;color:#6ee7b7}
.muted{color:var(--mut);font-size:.85rem}
.rep{border:1px solid var(--line);border-radius:10px;padding:10px 12px;margin:8px 0;background:#0d1420}
.rep h4{margin:0 0 6px;font-size:.9rem;display:flex;justify-content:space-between;align-items:center;gap:8px}
.st{font-size:.68rem;font-weight:700;padding:2px 8px;border-radius:999px}
.st.ok{background:var(--ok)22;color:var(--ok)}.st.fail{background:var(--err)22;color:var(--err)}.st.run{background:var(--warn)22;color:var(--warn)}
pre{margin:0;max-height:220px;overflow:auto;font-size:.76rem;color:#cbd5e1;background:#080c13;padding:8px;border-radius:7px;white-space:pre-wrap;word-break:break-word}
.map{width:100%;height:280px;border:0;border-radius:10px;margin-top:8px}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
@media(max-width:720px){.grid{grid-template-columns:1fr}}
a{color:var(--acc)}.spin{display:inline-block;width:14px;height:14px;border:2px solid #ffffff55;border-top-color:#fff;border-radius:50%;animation:s .7s linear infinite;vertical-align:-2px}
@keyframes s{to{transform:rotate(360deg)}}
.note{background:#1c1407;border:1px solid #4a3a12;color:#f5d58a;border-radius:10px;padding:10px 12px;font-size:.82rem;margin-bottom:16px}
</style></head><body><div class="wrap">
<h1><span class="logo">🦅</span> Vulture · IntelOwl demo</h1>
<div class="sub">Escribe una <b>IP</b> o un <b>nombre</b>. Síncrono = geoposición + reputación al instante · Asíncrono = enriquecimiento en segundo plano.</div>
<div class="note">⚖️ Uso responsable: analiza únicamente activos propios o con autorización explícita. Esto es OSINT sobre datos de terceros — aplica tu marco legal (LFPDPPP y equivalentes).</div>

<div class="card">
  <input id="target" type="text" placeholder="p.ej.  8.8.8.8   ·   example.com   ·   Juan Pérez" autofocus>
  <div class="row">
    <button class="b-sync" id="bs">⚡ Analizar (síncrono)</button>
    <button class="b-async" id="ba">🌙 Enviar a enriquecimiento (asíncrono)</button>
  </div>
  <div class="muted" style="margin-top:8px">IntelOwl: <span id="io">{{ intelowl }}</span> · <span id="hz">comprobando…</span></div>
</div>

<div id="out"></div>
</div>
<script>
const $=s=>document.querySelector(s);
fetch('/health').then(r=>r.json()).then(d=>{$('#hz').innerHTML=d.ok?'conectado ✓':'sin conexión ✗ ('+(d.error||'')+')';}).catch(()=>$('#hz').textContent='sin conexión ✗');
function esc(s){return (s==null?'':(''+s)).replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));}
function repCard(r){const ok=(r.status||'').includes('SUCCESS')||(r.status||'').includes('success');const run=(r.status||'').toLowerCase().includes('running')||(r.status||'').toLowerCase().includes('pending');
  const cls=ok?'ok':run?'run':'fail';
  return `<div class="rep"><h4><span>${esc(r.name)}</span><span class="st ${cls}">${esc(r.status||'—')}</span></h4><pre>${esc(JSON.stringify(r.report,null,2)).slice(0,4000)}</pre></div>`;}
function mapEmbed(lat,lon,src){const d=0.03;const bbox=[lon-d,lat-d,lon+d,lat+d].join(',');
  return `<div class="card"><h4 style="margin:0 0 6px">📍 Geoposición <span class="muted">(fuente: ${esc(src)})</span></h4>
   <div class="muted">lat ${lat} · lon ${lon} · <a href="https://www.openstreetmap.org/?mlat=${lat}&mlon=${lon}#map=12/${lat}/${lon}" target="_blank">abrir en OSM</a></div>
   <iframe class="map" src="https://www.openstreetmap.org/export/embed.html?bbox=${bbox}&layer=mapnik&marker=${lat},${lon}"></iframe></div>`;}
async function run(mode){const t=$('#target').value.trim();if(!t)return;
  $('#bs').disabled=$('#ba').disabled=true;
  $('#out').innerHTML=`<div class="card"><span class="spin"></span> ${mode==='sync'?'Analizando en línea…':'Enviando a segundo plano…'}</div>`;
  try{const r=await fetch('/analyze',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({target:t,mode})});
    const d=await r.json();
    if(!r.ok){$('#out').innerHTML=`<div class="card" style="border-color:var(--err)">✗ ${esc(d.error||'Error')}</div>`;return;}
    if(mode==='async'){$('#out').innerHTML=`<div class="card"><h3 style="margin:0 0 6px">🌙 En enriquecimiento — job #${d.job_id}</h3>
      <div class="muted">Tipo: <span class="pill ${d.classification}">${d.classification}</span> · ${d.analyzers.length} analizadores lanzados</div>
      <div class="muted" style="margin-top:6px">${esc(d.message)}</div>
      <div class="row"><a href="${d.job_url}" target="_blank"><button class="b-sync">Ver job en IntelOwl</button></a>
      <button class="b-async" id="poll">🔄 Consultar estado aquí</button></div>
      <div id="pollout" class="muted" style="margin-top:8px"></div></div>`;
      $('#poll').onclick=async()=>{const j=await (await fetch('/job/'+d.job_id)).json();
        $('#pollout').innerHTML='Estado: <b>'+esc(j.status)+'</b> — '+j.reports.map(x=>esc(x.name)+': '+esc(x.status)).join(' · ');};
      return;}
    // sync
    let html='';
    if(d.geo)html+=mapEmbed(d.geo.lat,d.geo.lon,d.geo.source);
    html+=`<div class="card"><h3 style="margin:0 0 4px">⚡ Resultado síncrono — job #${d.job_id}</h3>
      <div class="muted">Tipo: <span class="pill ${d.classification}">${d.classification}</span> · estado ${esc(d.status||'—')} · <a href="${d.job_url}" target="_blank">ver en IntelOwl</a></div>
      <div style="margin-top:10px">${d.reports.length?d.reports.map(repCard).join(''):'<div class="muted">Sin reportes (¿analizadores aún corriendo?).</div>'}</div>
      ${d.also_async&&d.also_async.length?`<div class="muted" style="margin-top:8px">💡 ${d.also_async.length} analizadores de enriquecimiento disponibles en modo asíncrono.</div>`:''}
      </div>`;
    $('#out').innerHTML=html;
  }catch(e){$('#out').innerHTML=`<div class="card" style="border-color:var(--err)">✗ ${esc(e.message)}</div>`;}
  finally{$('#bs').disabled=$('#ba').disabled=false;}
}
$('#bs').onclick=()=>run('sync');$('#ba').onclick=()=>run('async');
$('#target').addEventListener('keydown',e=>{if(e.key==='Enter')run('sync');});
</script></body></html>"""


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=PORT)
