# Laboratorio IntelOwl · homelab "vulture"

Demo de [IntelOwl](https://github.com/intelowlproject/IntelOwl) sobre la Legion7
(`192.168.1.73`) para mostrar cómo se consumen datos de OSINT/seguridad a partir
de una **IP** o un **nombre**: geoposición (GPS), reputación, DNS, etc., y la
diferencia entre lo que conviene resolver **en línea (síncrono)** y lo que se
deja para **enriquecimiento posterior (asíncrono)**.

```
┌──────────────────────────────────────────────────────────────┐
│  Legion7  (192.168.1.73)  ·  usuario: vulture                 │
│                                                                │
│  /home/vulture/intelowl   →  IntelOwl (Docker)   :80  (GUI/API)│
│  vulture/intelowl/webapp  →  Front "vulture"     :8666         │
│                                   │                            │
│   navegador  ──►  :8666  ──►  front  ──►  :80/api  ──►  IntelOwl│
└──────────────────────────────────────────────────────────────┘
```

## Contenido

```
vulture/intelowl/
├── deploy/
│   ├── bootstrap.sh          # opción A: 1 script (crea vulture, Docker, IntelOwl)
│   └── ansible/              # opción B: mismo despliegue con Ansible + explicación
├── intelowl/playbooks/
│   ├── create_playbooks.py   # arma los playbooks sync/async con analizadores gratis
│   └── README.md
├── webapp/                   # servicio web en :8666 (IP/nombre → análisis)
│   ├── app.py  Dockerfile  docker-compose.yml  requirements.txt  .env.example
└── README.md                 # este archivo
```

## Puesta en marcha (resumen)

### 1) Instalar IntelOwl
En la Legion7, con un usuario con sudo:
```bash
sudo bash deploy/bootstrap.sh          # crea 'vulture', instala Docker y clona IntelOwl
```
Luego, como `vulture`:
```bash
su - vulture
cd ~/intelowl
./start prod up -- -d                   # primera vez tarda: migraciones
docker exec -ti intelowl_uwsgi python3 manage.py createsuperuser
```
Abre `http://192.168.1.73/` → entra → crea tu **API token** en
*tu usuario → API Access/Sessions*.

*(Alternativa reproducible: `deploy/ansible/` — ver su README, incluye la
explicación de qué es Ansible y cuándo conviene.)*

### 2) Definir los playbooks (sync/async)
```bash
cd intelowl/playbooks
export INTELOWL_URL=http://localhost INTELOWL_TOKEN=<tu_token>
python3 create_playbooks.py
```

### 3) Levantar el front (:8666)
```bash
cd webapp
cp .env.example .env
nano .env                               # pega INTELOWL_TOKEN
docker compose up -d --build
```
Abre `http://192.168.1.73:8666`, escribe una IP (p.ej. `8.8.8.8`) o un nombre y
prueba **⚡ síncrono** y **🌙 asíncrono**.

## Síncrono vs asíncrono (lo que muestra la demo)

IntelOwl siempre corre los analizadores como *jobs* en segundo plano. La demo
convierte eso en dos experiencias:

| | Síncrono ⚡ | Asíncrono 🌙 |
|---|---|---|
| **Qué corre** | Analizadores rápidos (geo/GPS, reputación, DNS) | Enriquecimiento lento (DNS pasivo, correlaciones…) |
| **UX** | Espera unos segundos y pinta el resultado + mapa | Devuelve `job_id` y sigues; consultas después |
| **Para qué sirve** | Respuesta inmediata en pantalla | Acumular contexto para revisión posterior |

Así se ve claramente **qué datos se pueden consumir en línea** y **cuáles
conviene manejar de forma diferida** para enriquecer un caso más tarde.

## Posición GPS
La geolocalización nativa de IntelOwl usa **MaxMind GeoLite2** (licencia
*gratuita*, requiere registro). Si no la configuras, el front igual muestra la
posición con un servicio **sin key** (ip-api) como respaldo, etiquetado como tal,
para que la demo de GPS siempre funcione.

## ⚖️ Uso responsable
IntelOwl es una herramienta de OSINT/threat-intel potente. Úsala **solo** sobre
activos propios o con autorización explícita. Consultar datos de personas cae
bajo la **LFPDPPP** (y equivalentes): registra el propósito, minimiza datos y no
lo uses para perfilar personas sin base legal. Esta demo es para fines
educativos/defensivos en tu homelab.

## Notas de versión
IntelOwl evoluciona seguido. El front está hecho a prueba de cambios menores de
API (detecta `job_id`/`id`, campos de reporte, y descubre analizadores por
`/api/analyzer`). Si algo cambia, el mensaje de error del front y `/health` te
dicen qué falló.
