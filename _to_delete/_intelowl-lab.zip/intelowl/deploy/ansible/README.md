# Despliegue con Ansible (opcional)

## ¿Qué es Ansible y por qué usarlo?

Ansible es una herramienta de **automatización sin agente**: desde tu laptop (el
"nodo de control") describes en un archivo YAML el *estado* en que quieres que
quede otra máquina, y Ansible se conecta por **SSH** y lo aplica. No hay que
instalar nada en la Legion7 salvo Python (que Ubuntu ya trae).

### Ventaja frente a un script bash suelto

| | `bootstrap.sh` | Ansible (`site.yml`) |
|---|---|---|
| **Idempotencia** | Hay que cuidarla a mano | Nativa: solo cambia lo que falta |
| **Reproducible** | Sí, pero imperativo (pasos) | Sí, declarativo (estado deseado) |
| **Multi-máquina** | Copias el script a cada una | Un solo comando para N máquinas del inventario |
| **Legible / auditable** | Mezcla lógica y comandos | Cada tarea dice *qué* hace, no *cómo* |
| **Rollback / cambios** | Reescribir el script | Cambias el YAML y re-aplicas |

En un homelab de una sola máquina, el `bootstrap.sh` es más que suficiente y más
rápido de entender. Ansible **brilla cuando repites** el mismo setup (varias
máquinas, reinstalaciones, o quieres versionar la infraestructura como código).
Aquí te dejo ambos para que elijas — y para que veas cómo se ve el mismo
despliegue en los dos estilos.

## Cómo ejecutarlo

En tu nodo de control (tu laptop):

```bash
# 1) Instala Ansible (una vez)
sudo apt install -y ansible                       # Debian/Ubuntu
#  o:  pipx install ansible-core

# 2) Colección para manejar Docker
ansible-galaxy collection install community.docker

# 3) Edita inventory.ini y pon tu usuario SSH de la Legion7
nano inventory.ini

# 4) Aplica
ansible-playbook -i inventory.ini site.yml -K
```

`-K` pide la contraseña de `sudo` de la Legion7. Requiere que puedas entrar por
SSH a `192.168.1.73` con ese usuario (`ssh-copy-id` ayuda a dejar la llave).
