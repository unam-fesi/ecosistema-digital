#!/usr/bin/env bash
# ============================================================================
#  bootstrap.sh  ·  Laboratorio IntelOwl — homelab "vulture"
#  Objetivo: en un Ubuntu 26 limpio deja listo:
#    1) usuario  vulture  con sudo
#    2) Docker + Docker Compose plugin
#    3) IntelOwl clonado en  /home/vulture/intelowl  y levantado
#
#  Uso (en la Legion7, como usuario con sudo):
#     sudo bash bootstrap.sh
#
#  Es idempotente: puedes correrlo varias veces sin romper nada.
# ============================================================================
set -euo pipefail

VULTURE_USER="vulture"
VULTURE_HOME="/home/${VULTURE_USER}"
INTELOWL_DIR="${VULTURE_HOME}/intelowl"     # aquí vive el docker de IntelOwl
INTELOWL_REPO="https://github.com/intelowlproject/IntelOwl"

log(){ printf '\n\033[1;36m[bootstrap]\033[0m %s\n' "$*"; }
die(){ printf '\n\033[1;31m[error]\033[0m %s\n' "$*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || die "Corre este script con sudo/root."

# ─────────────────────────────────────────────────────────────
# 1) Usuario vulture con sudo
# ─────────────────────────────────────────────────────────────
if id "${VULTURE_USER}" &>/dev/null; then
  log "El usuario ${VULTURE_USER} ya existe."
else
  log "Creando usuario ${VULTURE_USER}…"
  adduser --disabled-password --gecos "" "${VULTURE_USER}"
  log "Asigna una contraseña para ${VULTURE_USER} (para poder hacer login/sudo):"
  passwd "${VULTURE_USER}"
fi
usermod -aG sudo "${VULTURE_USER}"
log "Usuario ${VULTURE_USER} en el grupo sudo ✓"

# ─────────────────────────────────────────────────────────────
# 2) Paquetes base + Docker
# ─────────────────────────────────────────────────────────────
log "Actualizando índice de paquetes…"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y ca-certificates curl git gnupg lsb-release python3 python3-pip

if ! command -v docker &>/dev/null; then
  log "Instalando Docker Engine (repositorio oficial)…"
  install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
  chmod a+r /etc/apt/keyrings/docker.asc
  # Ubuntu 26 (usa el codename real; si el repo aún no lo publica, cae a 'noble' 24.04 que es compatible)
  CODENAME="$(. /etc/os-release && echo "${VERSION_CODENAME:-noble}")"
  if ! curl -fsSILo /dev/null "https://download.docker.com/linux/ubuntu/dists/${CODENAME}/Release" 2>/dev/null; then
    log "El repo de Docker aún no publica '${CODENAME}'; uso 'noble' (compatible)."
    CODENAME="noble"
  fi
  echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu ${CODENAME} stable" \
    > /etc/apt/sources.list.d/docker.list
  apt-get update -y
  apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
else
  log "Docker ya está instalado."
fi
systemctl enable --now docker
usermod -aG docker "${VULTURE_USER}"
log "Docker listo y ${VULTURE_USER} agregado al grupo docker ✓"

# ─────────────────────────────────────────────────────────────
# 3) Clonar y levantar IntelOwl como vulture
# ─────────────────────────────────────────────────────────────
if [ ! -d "${INTELOWL_DIR}/.git" ]; then
  log "Clonando IntelOwl en ${INTELOWL_DIR}…"
  sudo -u "${VULTURE_USER}" git clone "${INTELOWL_REPO}" "${INTELOWL_DIR}"
else
  log "IntelOwl ya está clonado; hago git pull…"
  sudo -u "${VULTURE_USER}" git -C "${INTELOWL_DIR}" pull --ff-only || true
fi

log "Inicializando entorno de IntelOwl (./initialize.sh)…"
sudo -u "${VULTURE_USER}" bash -lc "cd '${INTELOWL_DIR}' && yes | ./initialize.sh || true"

cat <<EOF

────────────────────────────────────────────────────────────────────────────
  Casi listo. Los siguientes pasos se hacen como el usuario 'vulture'
  porque el grupo docker aplica tras reabrir sesión:

    su - vulture
    cd ~/intelowl

    # 1) Revisa credenciales/entorno (postgres, etc.)
    nano docker/env_file_app
    nano docker/env_file_postgres

    # 2) Levanta IntelOwl (primera vez tarda varios minutos: migraciones)
    ./start prod up -- -d

    # 3) Crea el usuario administrador de la GUI
    docker exec -ti intelowl_uwsgi python3 manage.py createsuperuser

    # 4) Entra a  http://192.168.1.73/  (login en /login)
    #    Crea tu API token en:  GUI → tu usuario → "API Access/Sessions"

  Cuando tengas el token, sigue con el servicio web (carpeta ../webapp).
────────────────────────────────────────────────────────────────────────────
EOF
log "bootstrap.sh terminó ✓"
