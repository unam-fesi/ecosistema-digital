#!/usr/bin/env bash
# 1 · SÍNCRONO · IP — geoposición + reputación
HOST="${HOST:-http://192.168.1.79:8666}"
DIR="$(cd "$(dirname "$0")" && pwd)"; FMT="$DIR/../presentacion/fmt.py"
TARGET="187.169.4.15"
curl -s -X POST "$HOST/analyze" -H "Content-Type: application/json" \
  -d "{\"target\":\"$TARGET\",\"mode\":\"sync\"}" | python3 "$FMT" "187.169.4.15"
