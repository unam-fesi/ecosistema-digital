#!/usr/bin/env bash
# 5 · SÍNCRONO · Dominio MALICIOSO de prueba (Cisco/OpenDNS)
HOST="${HOST:-http://192.168.1.79:8666}"
DIR="$(cd "$(dirname "$0")" && pwd)"; FMT="$DIR/../presentacion/fmt.py"
TARGET="internetbadguys.com"
curl -s -X POST "$HOST/analyze" -H "Content-Type: application/json" \
  -d "{\"target\":\"$TARGET\",\"mode\":\"sync\"}" | python3 "$FMT" "internetbadguys.com"
