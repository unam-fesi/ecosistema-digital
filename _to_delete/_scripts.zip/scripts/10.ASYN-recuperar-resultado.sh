#!/usr/bin/env bash
# 10 · ASÍNCRONO · Recuperar el resultado de un job (arg: job_id)
HOST="${HOST:-http://192.168.1.79:8666}"
DIR="$(cd "$(dirname "$0")" && pwd)"; FMT="$DIR/../presentacion/fmt.py"
JOB="${1:?Uso: bash 10.ASYN-recuperar-resultado.sh <job_id>   (el # que devolvió el envío asincrono)}"
curl -s "$HOST/result/$JOB" | python3 "$FMT" "enriquecimiento job $JOB"
