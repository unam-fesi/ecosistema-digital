#!/usr/bin/env bash
# 2 · SÍNCRONO · IP marcada por listas (nodo Tor)
HOST="${HOST:-http://192.168.1.79:8666}"
DIR="$(cd "$(dirname "$0")" && pwd)"; FMT="$DIR/../presentacion/fmt.py"
TARGET="185.220.101.1"
curl -s -X POST "$HOST/analyze" -H "Content-Type: application/json" \
  -d "{\"target\":\"$TARGET\",\"mode\":\"sync\"}" | python3 "$FMT" "Nodo Tor conocido"
