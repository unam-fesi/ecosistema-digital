#!/usr/bin/env bash
# 3 · SÍNCRONO · Dominio — DNS, certificados y DMARC
HOST="${HOST:-http://192.168.1.79:8666}"
DIR="$(cd "$(dirname "$0")" && pwd)"; FMT="$DIR/../presentacion/fmt.py"
TARGET="unam.mx"
curl -s -X POST "$HOST/analyze" -H "Content-Type: application/json" \
  -d "{\"target\":\"$TARGET\",\"mode\":\"sync\"}" | python3 "$FMT" "unam.mx"
