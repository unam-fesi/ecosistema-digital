#!/usr/bin/env bash
# 4 · SÍNCRONO · Correo → pivote a su dominio
HOST="${HOST:-http://192.168.1.79:8666}"
DIR="$(cd "$(dirname "$0")" && pwd)"; FMT="$DIR/../presentacion/fmt.py"
TARGET="kebov29097@netiren.com"
curl -s -X POST "$HOST/analyze" -H "Content-Type: application/json" \
  -d "{\"target\":\"$TARGET\",\"mode\":\"sync\"}" | python3 "$FMT" "correo desechable"
