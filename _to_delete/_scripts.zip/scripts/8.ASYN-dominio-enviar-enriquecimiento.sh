#!/usr/bin/env bash
# 8 · ASÍNCRONO · Enviar dominio a enriquecimiento
HOST="${HOST:-http://192.168.1.79:8666}"
DIR="$(cd "$(dirname "$0")" && pwd)"; FMT="$DIR/../presentacion/fmt.py"
TARGET="unam.mx"
curl -s -X POST "$HOST/analyze" -H "Content-Type: application/json" \
  -d "{\"target\":\"$TARGET\",\"mode\":\"async\"}" | python3 "$FMT" "unam.mx"
