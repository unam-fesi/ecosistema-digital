# Scripts de demo (uno por prueba)

Cada archivo ejecuta **una** prueba y formatea la salida con `../presentacion/fmt.py`.
Corre desde tu Mac (necesitas `python3`, que macOS ya trae).

```bash
cd ~/Work/UNAM/ecosistema-digital/vulture/intelowl/scripts
bash 1.Syn-IP-geoposicion-y-reputacion.sh
```

## Síncronos (respuesta inmediata)

| # | Script | Qué muestra |
|---|--------|-------------|
| 1 | `1.Syn-IP-geoposicion-y-reputacion.sh` | IP propia: geoposición + mapa + reputación (limpio) |
| 2 | `2.Syn-IP-marcada-por-listas.sh` | IP de nodo Tor: hallazgo de reputación |
| 3 | `3.Syn-dominio-DNS-cert-DMARC.sh` | Dominio: DNS, certificados, DMARC |
| 4 | `4.Syn-correo-pivote-a-dominio.sh` | Correo → analiza su dominio |
| 5 | `5.Syn-dominio-malicioso.sh` | Dominio MALICIOSO de prueba → ⚠ detectado |
| 6 | `6.Syn-hash-malware-EICAR.sh` | Hash EICAR → amenaza conocida |

## Asíncronos (enriquecimiento en segundo plano)

| # | Script | Qué muestra |
|---|--------|-------------|
| 7 | `7.ASYN-IP-enviar-enriquecimiento.sh` | Envía IP → devuelve `job #` al instante |
| 8 | `8.ASYN-dominio-enviar-enriquecimiento.sh` | Envía dominio → `job #` |
| 9 | `9.ASYN-dominio-malicioso-enriquecimiento.sh` | Envía dominio malicioso → `job #` |
| 10 | `10.ASYN-recuperar-resultado.sh <job_id>` | Recupera el resultado completo de un job |

Ejemplo del flujo asíncrono completo:
```bash
bash 7.ASYN-IP-enviar-enriquecimiento.sh      # anota el job # que imprime
bash 10.ASYN-recuperar-resultado.sh 21        # (unos segundos después)
```

> El host se puede cambiar con la variable `HOST`, p. ej.:
> `HOST=http://otra-ip:8666 bash 1.Syn-IP-geoposicion-y-reputacion.sh`

## Orden sugerido para el video
1 (limpio) → 5 (malicioso, contraste) → 4 (correo→dominio) → 7 + 10 (sync vs async).
